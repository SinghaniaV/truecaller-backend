vishal = Identity(name="Vishal Singhania", phone_number="7782874447", email_address="knownstranger10@gmail.com")

niha = Identity(name="Niha Singhania", phone_number="7362884417", email_address="knownstranger10@gmail.com")

juhi = Identity(name="Juhi Singhania", phone_number="7766031168", email_address="knownstranger10@gmail.com")